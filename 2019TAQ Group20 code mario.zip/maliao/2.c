char str1[20]; char str2[20]; char str3[20]; char str4[20]; char str5[20];
char str6[40]; char str7[20]; char str8[40]; char str9[20];
sprintf_s(str9, 19, "heart:%d", heart);
setTextSize(30);
paintText(10, 40, str9);
sprintf_s(str1, 19, "score:%d", score);
setTextSize(30);
paintText(10, 10, str1);
if (score>-50 && score<30)
{
	sprintf_s(str2, 19, "�ؿ�1!");
	setTextSize(30);
	paintText(800, 10, str2);
	playSound(EASY, 0);
}
if (score >= 30 && score<60)
{
	sprintf_s(str3, 19, "�ؿ�2!");
	setTextSize(30);
	paintText(800, 10, str3);
}
if (score >= 60 && score<100)
{
	sprintf_s(str4, 19, "�ؿ�3!");
	setTextSize(30);
	paintText(800, 10, str4);
}
if (score >= 100 && score<150)
{
	sprintf_s(str5, 19, "���չؿ�!");
	setTextSize(30);
	paintText(800, 10, str5);
}
if (score >= 150)
{
	sprintf_s(str6, 39, "��Ӯ��!��÷���������һ����");
	setTextSize(70);
	paintText(100, 70, str6);
}
if (score <= -50)
{
	sprintf_s(str7, 19, "tip!���Զ㵽���");
	setTextSize(20);
	paintText(100, 10, str7);
}
if (heart<0)
{
	sprintf_s(str8, 39, "������!��÷������ƨһ����");
	setTextSize(70);
	paintText(100, 70, str8);
}
