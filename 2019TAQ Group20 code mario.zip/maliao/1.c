#include"acllib.h"
const int winWidth = 1000, winHeight = 300;
ACL_Image marie_img;
const char *marie = "marie.jpg";
int marie_width = 30, marie_height = 30, marie_x = 10, marie_y = 130;
void paint();
void keyEvent(int key, int e);
int Setup()
{
	initWindow("super_marie", DEFAULT, DEFAULT, winWidth, winHeight);
	loadImage(marie, &marie_img);
	registerKeyboardEvent(keyEvent);
	paint();
	return 0;
}
void paint()
{
	beginPaint();
	clearDevice();
	putImageScale(&marie_img, marie_x, marie_y, marie_width, marie_height);
	endPaint();
}
void keyEvent(int key, int e)
{
	if (e != KEY_DOWN) return;
	switch (key)
	{
	case VK_UP:
		marie_y -= 5;
		if (marie_y <= 0) marie_y = 0;
		break;
	case VK_DOWN:
		marie_y += 5;
		if (marie_y >= winHeight - marie_height) marie_y = winHeight - marie_height;
		break;
	case VK_LEFT:
		marie_x -= 5;
		if (marie_x <= 0)marie_x = 0;
		break;
	case VK_RIGHT:
		marie_x += 5;
		if (marie_x >= winWidth - marie_width) marie_x = winWidth - marie_width;
		break;
	default:break;
	}
	paint();//�������»���
}
