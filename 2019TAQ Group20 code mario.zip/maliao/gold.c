typedef struct sprite
{
	int x, y;
	int width, height;
	int dx, dy;
}sprite;//����һ��ָ��ʹ���ֶ����������,bill�ĸ��������ֵ
sprite *billsprite[200] = { NULL };
sprite *goodmushsprite[1] = { NULL };
{goodmushsprite[numgoodmush] = (sprite*)malloc(sizeof(sprite));
goodmushsprite[numgoodmush]->width = 30;
goodmushsprite[numgoodmush]->height = 30;
goodmushsprite[numgoodmush]->x = rand() % (400);
goodmushsprite[numgoodmush]->y = 230;
goodmushsprite[numgoodmush]->dx = 8; }
//bill
{billsprite[numbill] = (sprite*)malloc(sizeof(sprite));
billsprite[numbill]->width = 20;
billsprite[numbill]->height = 20;
billsprite[numbill]->x = rand() % (winWidth - billsprite[numbill]->width);
billsprite[numbill]->y = rand() % (winHeight - wall_2_height - billsprite[numbill]->height);
billsprite[numbill]->dx = 2;
billsprite[numbill]->dy = 2; }
else if (id == 2)
{
	//int i = 0;
	for (i = 0; i <= numbill; i++)//bill�����г��ֵ�bill�����ƶ�
	{
		if (billsprite[i])
		{
			billsprite[i]->x += billsprite[i]->dx;
			billsprite[i]->y += billsprite[i]->dy;
			if (billsprite[i]->x <= 0 || billsprite[i]->x + billsprite[i]->width >= winWidth) billsprite[i]->dx = -billsprite[i]->dx;
			if (billsprite[i]->y <= 0 || billsprite[i]->y + billsprite[i]->height + wall_2_height >= winHeight) billsprite[i]->dy = -billsprite[i]->dy;
			rectmarie.x = marie_x;
			rectmarie.y = marie_y;
			rectmarie.w = marie_width;
			rectmarie.h = marie_height;
			rectbill[i].x = billsprite[i]->x;
			rectbill[i].y = billsprite[i]->y;
			rectbill[i].w = billsprite[i]->width;
			rectbill[i].h = billsprite[i]->height;

			if (collision(rectbill[i], rectmarie) == 1)
			{
				score += 2;
				billsprite[i] = NULL;
			}

		}
		//bill_bill[i]->y = rand() % (winHeight - marie_height - wall_2_height - bill_width);
		//bill_bill[i]->x = rand() % (winWidth - bill_height);// ��ֹ���ڱ߽�

	}
	//paint();
}
else if (id == 3)
{
	if (numbill<maxbill) numbill++;
	else numbill = 0;
	if (billsprite[numbill] == NULL)
	{
		billsprite[numbill] = (sprite*)malloc(sizeof(sprite));
		billsprite[numbill]->width = 20;
		billsprite[numbill]->height = 20;
		billsprite[numbill]->x = rand() % (winWidth - billsprite[numbill]->width);
		billsprite[numbill]->y = rand() % (winHeight - wall_2_height - billsprite[numbill]->height);
		billsprite[numbill]->dx = 2;
		billsprite[numbill]->dy = 2;
	}
}
