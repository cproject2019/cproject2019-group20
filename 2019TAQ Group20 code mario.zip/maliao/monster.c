if (score <= 60)putImageScale(&background_1_img, background_1_x, background_1_y, background_1_width, background_1_height);
if (score>60)putImageScale(&background_2_img, background_2_x, background_2_y, background_2_width, background_2_height);
putImageScale(&marie_img, marie_x, marie_y, marie_width, marie_height);
putImageScale(&bad_missile_img, bad_missile_x, bad_missile_y, bad_missile_width, bad_missile_height);
if (score >= 30)putImageScale(&bad_mask_img, bad_mask_x, bad_mask_y, bad_mask_width, bad_mask_height);
putImageScale(&wall_2_img, wall_2_x, wall_2_y, wall_2_width, wall_2_height);
putImageScale(&bad_green_turtle_img, bad_green_turtle_x, bad_green_turtle_y, bad_green_turtle_width, bad_green_turtle_height);
putImageScale(&greenpole_img, greenpole_x, greenpole_y, greenpole_width, greenpole_height);
if (score >= 100)putImageScale(&bad_snake_img, bad_snake_x, bad_snake_y, bad_snake_width, bad_snake_height);
if (score >= 100)putImageScale(&bad_mush_img, bad_mush_x, bad_mush_y, bad_mush_width, bad_mush_height);
//putImageScale(&bill_img, bill_x, bill_y, bill_width, bill_height);
for (int j = 0; j <= numbill; j++)
{
	if (billsprite[j]) putImageScale(&bill_img, billsprite[j]->x, billsprite[j]->y, billsprite[j]->width, billsprite[j]->height);
}//������bill���Ƴ���
for (int j = 0; j <= 0; j++)
{
	if (goodmushsprite[j])putImageScale(&good_mush2_img, goodmushsprite[j]->x, goodmushsprite[j]->y, goodmushsprite[j]->width, goodmushsprite[j]->height);
}
