if (score <= 60)putImageScale(&background_1_img, background_1_x, background_1_y, background_1_width, background_1_height);
if (score>60)putImageScale(&background_2_img, background_2_x, background_2_y, background_2_width, background_2_height);
